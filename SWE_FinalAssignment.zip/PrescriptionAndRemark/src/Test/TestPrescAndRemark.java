package Test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

class TestPrescAndRemark {

    @Test
    void testAddPrescription_validInputs() {
        // Ensure to pass a Date object for the examinationDate parameter
        PrescAndRemark prescription = new PrescAndRemark("Prince", "Shovon", "143 Love St, Melbourne, 3000, Australia", -10.00f, 90, -2.00f, new Date(), "Robert Downey");
        // Valid inputs to pass the test
        assertTrue(prescription.addPrescription());  // This should pass because the prescription is valid
    }

    @Test
    void testAddPrescription_invalidFirstName() {
        PrescAndRemark prescription = new PrescAndRemark("Pri", "Shovon", "143 Love St, Melbourne, 3000, Australia", -10.00f, 90, -2.00f, new Date(), "Robert Downey");
        // First name is too short (less than 4 characters), so it should not add the prescription
        assertFalse(prescription.addPrescription());  // This should pass, meaning the prescription is not added
    }

    @Test
    void testAddPrescription_invalidLastName() {
        PrescAndRemark prescription = new PrescAndRemark("Prince", "Deb", "143 Love St, Melbourne, 3000, Australia", -10.00f, 90, -2.00f, new Date(), "Robert Downey");
        // Last name is too short (less than 4 characters), so the prescription should not be added
        assertFalse(prescription.addPrescription());  // This should pass as the last name is invalid
    }

    @Test
    void testAddPrescription_invalidAddress() {
        PrescAndRemark prescription = new PrescAndRemark("Prince", "Shovon", "Test Address", -10.00f, 90, -2.00f, new Date(), "Robert Downey");
        // Address is less than 20 characters, so the prescription should not be added
        assertFalse(prescription.addPrescription());  // This should pass as the address is invalid
    }

    @Test
    void testAddPrescription_invalidSphere() {
        PrescAndRemark prescription = new PrescAndRemark("Prince", "Shovon", "143 Love St, Melbourne, 3000, Australia", -25.00f, 90, -2.00f, new Date(), "Robert Downey");
        // Sphere is out of the valid range (-20.00 to 20.00), so the prescription should not be added
        assertFalse(prescription.addPrescription());  // This should pass as the sphere value is invalid
    }

    @Test
    void testAddPrescription_invalidOptometristName() {
        PrescAndRemark prescription = new PrescAndRemark("Prince", "Shovon", "143 Love St, Melbourne, 3000, Australia", -10.00f, 90, -2.00f, new Date(), "Rob");
        // Optometrist name is too short (less than 8 characters), so the prescription should not be added
        assertFalse(prescription.addPrescription());  // This should pass as the optometrist name is invalid
    }

    @Test
    void testAddRemark_validRemark() {
        PrescAndRemark prescription = new PrescAndRemark("Prince", "Shovon", "143 Love St, Melbourne, 3000, Australia", -10.00f, 90, -2.00f, new Date(), "Robert Downey");
        // Valid remark and category, should be added successfully
        assertTrue(prescription.addRemark("The client is satisfied with the service.", "Client"));  // This should pass
    }

    @Test
    void testAddRemark_invalidWordCount() {
        PrescAndRemark prescription = new PrescAndRemark("Prince", "Shovon", "143 Love St, Melbourne, 3000, Australia", -10.00f, 90, -2.00f, new Date(), "Robert Downey");
        // Remark has fewer than 6 words, so it should not be added
        assertFalse(prescription.addRemark("Service good.", "Client"));  // This should pass because the word count is too low
    }

    @Test
    void testAddRemark_invalidCategory() {
        PrescAndRemark prescription = new PrescAndRemark("Prince", "Shovon", "143 Love St, Melbourne, 3000, Australia", -10.00f, 90, -2.00f, new Date(), "Robert Downey");
        // Category is invalid ("Guest"), so the remark should not be added
        assertFalse(prescription.addRemark("The client is satisfied with the service.", "Guest"));  // This should pass because the category is invalid
    }

    @Test
    void testAddRemark_invalidCapitalization() {
        PrescAndRemark prescription = new PrescAndRemark("Prince", "Shovon", "143 Love St, Melbourne, 3000, Australia", -10.00f, 90, -2.00f, new Date(), "Robert Downey");
        // First word is not capitalized, so the remark should not be added
        assertFalse(prescription.addRemark("the client is satisfied with the service.", "Client"));  // This should pass as the capitalization is wrong
    }

    @Test
    void testAddRemark_exceedRemarkLimit() {
        PrescAndRemark prescription = new PrescAndRemark("Prince", "Shovon", "143 Love St, Melbourne, 3000, Australia", -10.00f, 90, -2.00f, new Date(), "Robert Downey");
        // Adding two valid remarks
        prescription.addRemark("The client is satisfied with the service test.", "Client");
        prescription.addRemark("The optometrist suggested new lenses. It also required adjustments with the frame.", "Optometrist");
        // Attempt to add a third remark, which should fail because only two remarks are allowed
        assertFalse(prescription.addRemark("Additional remark for client as he needs another visit.", "Client"));  // This should pass as it exceeds the remark limit
    }

    @Test
    void testAddRemark_invalidCategorySecondTest() {
        PrescAndRemark prescription = new PrescAndRemark("Prince", "Shovon", "143 Love St, Melbourne, 3000, Australia", -10.00f, 90, -2.00f, new Date(), "Robert Downey");
        // Adding two valid remarks with valid categories
        prescription.addRemark("The client is satisfied with the service.", "Patient");  // Invalid category
        prescription.addRemark("The optometrist suggested new lenses.", "Optometrist");
        assertFalse(prescription.addRemark("The client is happy.", "Patient"));  // Invalid category "Patient"
    }
}
