package Test;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class PrescAndRemark {
    private String firstName;
    private String lastName;
    private String address;
    private float sphere;
    private float axis;
    private float cylinder;
    private Date examinationDate;
    private String optometrist;
    private ArrayList<String> remarks = new ArrayList<>();

    // Constructor name fixed to match the class name
    public PrescAndRemark(String firstName, String lastName, String address, float sphere, float axis, float cylinder, Date examinationDate, String optometrist) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
        this.sphere = sphere;
        this.axis = axis;
        this.cylinder = cylinder;
        this.examinationDate = examinationDate;
        this.optometrist = optometrist;
    }

    // Method to add prescription details to a file if they meet the required conditions
    public boolean addPrescription() {
        // Condition 1: Check first and last name lengths
        if (firstName.length() < 4 || firstName.length() > 15 || lastName.length() < 4 || lastName.length() > 15) {
            return false;
        }

        // Condition 2: Check address length
        if (address.length() < 20) {
            return false;
        }

        // Condition 3: Check Sphere, Cylinder, and Axis ranges
        if (sphere < -20.00 || sphere > 20.00 || axis < 0 || axis > 180 || cylinder < -4.00 || cylinder > 4.00) {
            return false;
        }

        // Condition 5: Check optometrist name length
        if (optometrist.length() < 8 || optometrist.length() > 25) {
            return false;
        }

        // If all conditions are met, write to the file
        try (FileWriter writer = new FileWriter("prescription.txt", true)) {
            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yy");
            String formattedDate = formatter.format(examinationDate);
            writer.write(firstName + " " + lastName + ", " + address + ", Sphere: " + sphere + 
                         ", Axis: " + axis + ", Cylinder: " + cylinder + ", Exam Date: " + formattedDate + 
                         ", Optometrist: " + optometrist + "\n");
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }

        return true;
    }

    // Method to add a remark for the prescription if it meets the required conditions
    public boolean addRemark(String remark, String category) {
        // Check if adding this remark exceeds the limit
        if (remarks.size() >= 2) {
            System.out.println("Failed: Cannot add remark. Remark limit exceeded.");
            return false;  // Fail if adding this remark would exceed the limit
        }

        // Validate the remark length (must be between 6 and 20 words)
        String[] words = remark.split(" ");
        if (words.length < 6 || words.length > 20) {
            System.out.println("Failed: Invalid word count.");
            return false;  // Fail if word count is not in the correct range
        }

        // Validate capitalization of the first word
        if (!Character.isUpperCase(words[0].charAt(0))) {
            System.out.println("Failed: First word is not capitalized.");
            return false;  // Fail if first word is not capitalized
        }

        // Validate the category (must be "Client" or "Optometrist")
        if (!category.equalsIgnoreCase("Client") && !category.equalsIgnoreCase("Optometrist")) {
            System.out.println("Failed: Invalid category.");
            return false;  // Fail if category is neither "Client" nor "Optometrist"
        }

        // Only now we add the remark to the list and then write to the file
        remarks.add(remark);
        
        // Step 5: Write to file if everything is valid
        try (FileWriter writer = new FileWriter("review.txt", true)) {
            writer.write("Category: " + category + ", Remark: " + remark + "\n");
            System.out.println("Remark added successfully.");
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }

        return true;
    }


}
